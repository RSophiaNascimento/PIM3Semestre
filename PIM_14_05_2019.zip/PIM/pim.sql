-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.1.37-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para pim
CREATE DATABASE IF NOT EXISTS `pim` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pim`;

-- Copiando estrutura para tabela pim.motorista
CREATE TABLE IF NOT EXISTS `motorista` (
  `id_motorista` int(11) NOT NULL AUTO_INCREMENT,
  `nome_motorista` varchar(50) NOT NULL,
  `end_motorista` varchar(100) NOT NULL,
  `telefone_motorista` varchar(15) NOT NULL,
  `doc_motorista` varchar(30) DEFAULT NULL,
  `CNH` varchar(30) NOT NULL,
  `categoriaHabilitacao` varchar(10) DEFAULT NULL,
  `data_venc_CNH` date NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `situacao` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_motorista`),
  KEY `id_motorista` (`id_motorista`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.motorista: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `motorista` DISABLE KEYS */;
INSERT INTO `motorista` (`id_motorista`, `nome_motorista`, `end_motorista`, `telefone_motorista`, `doc_motorista`, `CNH`, `categoriaHabilitacao`, `data_venc_CNH`, `status`, `situacao`) VALUES
	(1, 'kayque Prado', 'Av. Cancioneiro popular, N25 - Chac. Santo Antonio', '11 98888-8888', '46253047841', '08862453602', 'A', '2009-05-07', 'Vencida', 'Suspenso'),
	(2, 'Amaral', 'Av. Cancioneiro popular, N25 - Chac. Santo Antonio', '11 98888-8888', '25577293022', '08862453602', 'B', '2029-05-07', 'Ativo', 'Ativo'),
	(3, 'Amarelo', 'Av. Cancioneiro popular, N25 - Chac. Santo Antonio', '11 98888-8888', '25577293022', '08862453602', 'C', '2029-05-07', 'Ativo', 'Desligado');
/*!40000 ALTER TABLE `motorista` ENABLE KEYS */;

-- Copiando estrutura para tabela pim.ordemservicos
CREATE TABLE IF NOT EXISTS `ordemservicos` (
  `id_os` int(11) NOT NULL AUTO_INCREMENT,
  `ordem_servico` varchar(50) NOT NULL,
  `cliente` varchar(50) DEFAULT NULL,
  `id_motorista` int(11) NOT NULL,
  `id_veiculo` int(11) NOT NULL,
  `custo_combustivel` decimal(7,2) NOT NULL,
  `custo_pedagio` decimal(7,2) DEFAULT NULL,
  `custo_aliment` decimal(7,2) DEFAULT NULL,
  `custo_extra` decimal(7,2) DEFAULT NULL,
  `valor_liquido_OS` decimal(7,2) NOT NULL,
  `data_OS` date NOT NULL,
  PRIMARY KEY (`id_os`),
  KEY `Coluna 2` (`id_os`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.ordemservicos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `ordemservicos` DISABLE KEYS */;
INSERT INTO `ordemservicos` (`id_os`, `ordem_servico`, `cliente`, `id_motorista`, `id_veiculo`, `custo_combustivel`, `custo_pedagio`, `custo_aliment`, `custo_extra`, `valor_liquido_OS`, `data_OS`) VALUES
	(1, '05246', 'Vale', 1, 1, 254.00, NULL, NULL, NULL, 364.00, '2019-05-14');
/*!40000 ALTER TABLE `ordemservicos` ENABLE KEYS */;

-- Copiando estrutura para tabela pim.perfil
CREATE TABLE IF NOT EXISTS `perfil` (
  `id_perfil` int(11) NOT NULL AUTO_INCREMENT,
  `perfil` varchar(50) DEFAULT NULL,
  `access` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_perfil`),
  KEY `id_perfil` (`id_perfil`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.perfil: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `perfil` DISABLE KEYS */;
INSERT INTO `perfil` (`id_perfil`, `perfil`, `access`) VALUES
	(1, 'admin', 'all');
/*!40000 ALTER TABLE `perfil` ENABLE KEYS */;

-- Copiando estrutura para tabela pim.seguros
CREATE TABLE IF NOT EXISTS `seguros` (
  `id_seguro` int(11) NOT NULL AUTO_INCREMENT,
  `id_carro` int(11) NOT NULL,
  `nome_seguro` varchar(50) DEFAULT NULL,
  `valor` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id_seguro`),
  KEY `Coluna 1` (`id_seguro`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.seguros: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `seguros` DISABLE KEYS */;
INSERT INTO `seguros` (`id_seguro`, `id_carro`, `nome_seguro`, `valor`) VALUES
	(2, 1, 'Porto Seguro', 10.00);
/*!40000 ALTER TABLE `seguros` ENABLE KEYS */;

-- Copiando estrutura para tabela pim.users
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_perfil` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.users: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id_user`, `id_perfil`, `username`, `password`) VALUES
	(1, 1, 'admin', 'admin');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Copiando estrutura para tabela pim.veiculo
CREATE TABLE IF NOT EXISTS `veiculo` (
  `id_veiculo` int(11) NOT NULL AUTO_INCREMENT,
  `modelo` varchar(50) NOT NULL,
  `placa` varchar(50) NOT NULL,
  `ano_modelo` int(10) NOT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `id_seguros` int(11) DEFAULT NULL,
  `abastecimento` int(11) NOT NULL,
  `documento` varchar(10) DEFAULT NULL,
  `km` int(12) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_veiculo`),
  KEY `id_veiculo` (`id_veiculo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela pim.veiculo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `veiculo` DISABLE KEYS */;
INSERT INTO `veiculo` (`id_veiculo`, `modelo`, `placa`, `ano_modelo`, `marca`, `id_seguros`, `abastecimento`, `documento`, `km`, `status`) VALUES
	(1, 'Onix', 'EMU-5454', 2017, 'Chevrolet', 1, 10, 'Ok', 25000, 'Disponivel');
/*!40000 ALTER TABLE `veiculo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
